# Payment Risk Check Lite — Quick Start

Version 1.0.0 — 2026-07-14

This free, macro-free Excel sample puts order amount, paid amount, due date, and collection status in one table so you can spot missing fields, duplicate IDs, invalid amounts, and overdue balances.

## Start in two minutes

1. Open `02-payment-risk-check-lite-demo.xlsx` to review Valid and red issue rows.
2. Copy `01-payment-risk-check-lite-blank.xlsx` as your working file.
3. Fill only yellow cells; gray cells contain formulas.
4. Keep an untouched backup before pasting real records.

## Lite includes

- Up to 100 order rows.
- Five KPIs: valid orders, valid order amount, outstanding, overdue outstanding, and data issues.
- Checks for duplicate Order ID, missing Customer Code or Due Date, and invalid order or paid amounts.
- No VBA, external connections, banking connection, or platform API.

The paid edition adds 500 rows, monthly summaries, charts, item and channel analysis, more dropdowns, and broader buyer documentation. The public Lite product page should contain one current upgrade link; this ZIP intentionally does not contain a guessed or private URL.

This operational sample is not accounting, tax, legal, collection, invoicing, banking, or payment software and does not guarantee revenue, collection, or data accuracy. All demo data is fictional. Back up, validate formulas, and assess privacy, permissions, security, and legal duties before use.

